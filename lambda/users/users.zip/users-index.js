console.log('Loading function')

// dependencies
var AWS = require("aws-sdk")
var DOC = require("dynamodb-doc")
var async = require('async')

var dynamodb = new AWS.DynamoDB()

exports.handler = function(event, context){
	console.log('Querying for all users')
	
	var LastEvaluatedKey = event.LastEvaluatedKey
	var usersParams = {
		TableName           : 'ConappsUsers',
		ProjectionExpression: 'username, email',
		Limit               : 10
	}
	var countsParams = {
		TableName: 'ConappsCounts',
		KeyConditionExpression: '#table = ConappsUsers',
		ExpressionAttributeName: {
			'#table': 'table'
		},
		ProjectionExpression: 'count',
		ConsistentRead: true
	}

	if (!!LastEvaluatedKey)
		params.LastEvaluatedKey = LastEvaluatedKey

	console.log('Ejecutando consulta a ConappsUsers')
	/*
	dynamodb.scan(usersParams, function(err, data){
		if (err)
			context.fail("Imposible realizar la consulta. Error ", JSON.stringify(err, null, 2))
		else {
			console.log('Consulta exitosa')
			context.succeed(data)
		}
	})
	*/

	async.
		parallel(
		//[
		//	function(callback){callback(null, {1:2})},
		//	function(callback){callback(null, {3:5})}
		//],
		[
			function(callback){ dynamodb.scan(usersParams, callback) },
			function(callback){ dynamodb.query(countsParams, callback) }
		], 
		function(err, results){
			var data;
			if (err)
				context.fail("Imposible realizar la consulta. Error ", JSON.stringify(err, null, 2))
			else {
				console.log('Consulta exitosa')
				data = results[0]
				data.Count = results[1]
				context.succeed(data)
			}
		})
}