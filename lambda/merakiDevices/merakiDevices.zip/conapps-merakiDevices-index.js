var AWS = require('aws-sdk')
var vogels = require('vogels')
var Joi = require('Joi')

var dynamodb = new AWS.DynamoDB()

vogels.AWS.config.update({region: 'us-east-1'})
vogels.dynamoDriver(dynamodb)

var MerakiDevice = vogels.define('MerakiDevice', {
	hashKey: 'PartNumber',
	rangeKey: 'Category',
	timestamps: true,
	tableName: 'ConappsMerakiDevices',
	schema: {
		ID: vogels.types.uuid(),
		Desciption: Joi.string(),
		Price: Joi.number()
	}
})

exports.handler = function(event, context){

	var paginationKey = event.paginationKey

	var query = MerakiDevice.
		scan().
		limit(10).
		descending().
		
	if (!!paginationKey)
		query =	query.startKey(paginationKey)

	query.
		exec(function(err, data){
			if (err){
				console.log('Error after running scan: ' + err)
				context.fail('Error al ejecutar la consulta a la base de datos')
				return
			}
			console.log('Success!')
			context.succeed(data)
		})
}